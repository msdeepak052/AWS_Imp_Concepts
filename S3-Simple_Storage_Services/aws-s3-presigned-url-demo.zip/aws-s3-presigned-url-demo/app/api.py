from flask import Flask, jsonify, request
import boto3

from config import get_config

app = Flask(__name__)


@app.get("/presign-download")
def presign_download():
    key = request.args.get("key", "")

    # Demo allow-list. In production, authorize the authenticated user
    # and derive the object key from your application data.
    if not key.startswith("private/"):
        return jsonify({"error": "Only private/ keys are allowed"}), 400

    region, bucket = get_config()
    s3 = boto3.client("s3", region_name=region)

    url = s3.generate_presigned_url(
        ClientMethod="get_object",
        Params={"Bucket": bucket, "Key": key},
        ExpiresIn=300,
    )

    return jsonify({"url": url, "expires_in": 300})


@app.post("/presign-upload")
def presign_upload():
    body = request.get_json(silent=True) or {}
    key = body.get("key", "")
    content_type = body.get("content_type", "")

    if not key.startswith("uploads/"):
        return jsonify({"error": "Only uploads/ keys are allowed"}), 400

    allowed_types = {"text/plain", "image/jpeg", "image/png"}
    if content_type not in allowed_types:
        return jsonify({"error": "Unsupported content type"}), 400

    region, bucket = get_config()
    s3 = boto3.client("s3", region_name=region)

    url = s3.generate_presigned_url(
        ClientMethod="put_object",
        Params={
            "Bucket": bucket,
            "Key": key,
            "ContentType": content_type,
        },
        ExpiresIn=300,
        HttpMethod="PUT",
    )

    return jsonify({"url": url, "expires_in": 300, "key": key})
