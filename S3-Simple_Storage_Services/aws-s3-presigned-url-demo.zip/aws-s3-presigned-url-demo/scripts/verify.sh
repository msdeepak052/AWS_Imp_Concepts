#!/usr/bin/env bash
set -euo pipefail

: "${S3_BUCKET:?Set S3_BUCKET first}"
: "${AWS_REGION:?Set AWS_REGION first}"

URL="$(python app/presign_get.py private/report.txt)"

echo "Presigned URL:"
echo "$URL"

curl -fL "$URL" -o /tmp/presigned-demo-downloaded.txt

echo
echo "Downloaded content:"
cat /tmp/presigned-demo-downloaded.txt
echo
