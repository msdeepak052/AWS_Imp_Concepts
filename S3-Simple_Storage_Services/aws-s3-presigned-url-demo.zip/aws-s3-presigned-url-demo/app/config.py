import os


def get_config():
    region = os.environ.get("AWS_REGION") or os.environ.get("AWS_DEFAULT_REGION")
    bucket = os.environ.get("S3_BUCKET")

    if not region:
        raise RuntimeError("Set AWS_REGION or AWS_DEFAULT_REGION.")
    if not bucket:
        raise RuntimeError("Set S3_BUCKET.")

    return region, bucket
