# AWS S3 Presigned URL — End-to-End Python Demo

This demo uses a **private S3 bucket** and least-privilege IAM permissions.

It demonstrates:
- Presigned GET URL for private downloads
- Presigned PUT URL for direct browser/client uploads
- Optional Flask API
- S3 Block Public Access
- Least-privilege IAM policy

## Architecture

```text
Client
  |
  | request temporary URL
  v
Python application
  |
  | IAM-authorized boto3 call
  v
Private S3 bucket
  |
  | signed URL
  v
Client
  |
  | HTTPS GET/PUT
  v
S3 object
```

The client never receives AWS access keys.

## Prerequisites

- AWS account
- AWS CLI configured
- Python 3.10+
- boto3
- An S3 bucket

## 1. Create the bucket

Create a bucket in the AWS S3 console, for example:

```text
deepak-presigned-demo-2026-12345
```

Recommended:
- Object Ownership: Bucket owner enforced
- Block all public access: ON
- Default encryption: ON
- Keep the bucket private

## 2. IAM least-privilege policy

Edit `iam/app-presigned-s3-policy.json` and replace `YOUR_BUCKET`.

The application is allowed only to:
- `GetObject` under `private/*`
- `PutObject` under `uploads/*`

It cannot list, delete, or administer the bucket.

If you need download-only access, remove the PUT statement.

## 3. Upload a private test object

```bash
echo "This is a private S3 object." > report.txt
aws s3 cp report.txt s3://YOUR_BUCKET/private/report.txt
```

This command is for your setup/admin identity. The application role does not need this permission.

## 4. Install Python dependencies

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

Set:

```bash
export AWS_REGION=ap-south-1
export S3_BUCKET=YOUR_BUCKET
```

Do not hard-code AWS access keys in the code.

## 5. Generate a presigned GET URL

```bash
python app/presign_get.py private/report.txt
```

Copy the printed URL into a browser, or:

```bash
curl -L "PASTE_URL_HERE" -o downloaded-report.txt
```

The bucket remains private.

## 6. Generate a presigned PUT URL

```bash
python app/presign_put.py uploads/demo.txt text/plain
```

Then upload:

```bash
curl -X PUT   -H "Content-Type: text/plain"   --data-binary @report.txt   "PASTE_URL_HERE"
```

The object is written to:

```text
s3://YOUR_BUCKET/uploads/demo.txt
```

## 7. Optional Flask API

Run:

```bash
flask --app app.api run --host 127.0.0.1 --port 5000
```

Download URL:

```bash
curl "http://127.0.0.1:5000/presign-download?key=private/report.txt"
```

Upload URL:

```bash
curl -X POST http://127.0.0.1:5000/presign-upload   -H 'Content-Type: application/json'   -d '{"key":"uploads/api-demo.txt","content_type":"text/plain"}'
```

## Security notes

A presigned URL is a **bearer token**. Anyone who obtains a valid URL can use it until it expires, subject to the signing credentials and request conditions.

Use short expirations appropriate to the use case. The demo defaults to 5 minutes.

Do not log complete presigned URLs in production logs.

Do not trust arbitrary object keys supplied by clients. Authenticate the user and authorize the requested resource before generating a URL.

For uploads, validate file type and size. For larger browser uploads, consider presigned POST or multipart upload.

## Least privilege

The demo deliberately scopes permissions to:

```text
private/*  -> s3:GetObject
uploads/*  -> s3:PutObject
```

A real multi-tenant application should normally make the prefix even narrower, for example:

```text
arn:aws:s3:::YOUR_BUCKET/private/customer-123/*
```

## Key concept

A presigned URL does **not** make an S3 bucket public.

```text
Private bucket
     |
     +-- authorized application
     |
     +-- temporary signed URL
                  |
                  v
                client
                  |
                  v
                  S3
```
