import argparse
import boto3

from config import get_config


def generate_download_url(key: str, expires_in: int = 300) -> str:
    region, bucket = get_config()
    s3 = boto3.client("s3", region_name=region)

    return s3.generate_presigned_url(
        ClientMethod="get_object",
        Params={
            "Bucket": bucket,
            "Key": key,
        },
        ExpiresIn=expires_in,
    )


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("key")
    parser.add_argument("--expires-in", type=int, default=300)
    args = parser.parse_args()

    print(generate_download_url(args.key, args.expires_in))
