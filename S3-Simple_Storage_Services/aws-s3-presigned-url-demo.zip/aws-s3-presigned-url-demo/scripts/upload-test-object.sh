#!/usr/bin/env bash
set -euo pipefail

: "${S3_BUCKET:?Set S3_BUCKET first}"

printf '%s\n' 'This is a private S3 object.' > /tmp/presigned-demo-report.txt

aws s3 cp /tmp/presigned-demo-report.txt \
  "s3://${S3_BUCKET}/private/report.txt"

echo "Uploaded: s3://${S3_BUCKET}/private/report.txt"
